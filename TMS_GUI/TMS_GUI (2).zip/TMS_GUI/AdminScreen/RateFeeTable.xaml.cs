﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AdminScreen
{
    /// <summary>
    /// Interaction logic for RateFeeTable.xaml
    /// </summary>
    public partial class RateFeeTable : Window
    {
        public RateFeeTable()
        {
            InitializeComponent();
        }


        /**
         * <summary>
         * Updates the Information entered by the administrator
         * </summary>
         * 
         * <param name="e">The state of the click object</param>
         * <param name="sender">The object that is being passed</param>
         * 
         * <details>
         * The admin can adjust the FTL LTL and Reef rates for each Carrier and each City, by adjusting the values in the fields
         * </details>
         * 
         * <returns>
         * No Return (void)
         * </returns>
         */
        private void updateTable_Click(object sender, RoutedEventArgs e)
        {

        }





        /**
        * <summary>
        * Closes the Rate/Fee Table Window
        * </summary>
        * 
        * <param name="e">The state of the click object</param>
        * <param name="sender">The object that is being passed</param>
        * 
        * <details>
        * Closes the Rate/Fee Table and returns to the AdminScreen
        * </details>
        * 
        * <returns>
        * No Return (void)
        * </returns>
        */
        private void close_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
