﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PlannerScreen
{
    /** 
     * <summary>
     * Interaction logic for MainWindow.xaml
     * </summary>
     * 
     * <details>
     * Planner Main Window interaction logic for TMS
     * </details>
    */
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }



        /**
         * <summary>
         * Logs the Planner Out of the system
         * </summary>
         * 
         * <param name="e">The state of the click object</param>
         * <param name="sender">The object that is being passed</param>
         * 
         * <details>
         * Logs the PLanner out of the system and returns to the Login Window;
         * Same as using close window in upper corner.
         * </details>
         * 
         * <returns>
         * No Return (void)
         * </returns>
         */
        private void logout_Click(object sender, RoutedEventArgs e)
        {

        }



        /**
         * <summary>
         * Receives a pending Order from the Buyer
         * </summary>
         * 
         * <param name="e">The state of the click object</param>
         * <param name="sender">The object that is being passed</param>
         * 
         * <details>
         * Receives a pending Order from the Buyer and opens a dialog window for the planner to
         * select the available Carriers from the targeted Cities, if the Order exceeds capacity
         * additional Trips are added until Order can be fulfilled.
         * </details>
         * 
         * <returns>
         * No Return (void)
         * </returns>
         */
        private void receiveOrder_Click(object sender, RoutedEventArgs e)
        {

        }




        /**
         * <summary>
         * Simulate the passage of One Days Time
         * </summary>
         * 
         * <param name="e">The state of the click object</param>
         * <param name="sender">The object that is being passed</param>
         * 
         * <details>
         * Simulates the passage of 1-Day so the Order can be moved into its
         * completed state.
         * </details>
         * 
         * <returns>
         * No Return (void)
         * </returns>
         */
        private void simulateDay_Click(object sender, RoutedEventArgs e)
        {

        }




        /**
         * <summary>
         * Confirm Order is completed
         * </summary>
         * 
         * <param name="e">The state of the click object</param>
         * <param name="sender">The object that is being passed</param>
         * 
         * <details>
         * Planner confirms that the Order is completed and are sent back to the Buyer
         * to generate an Invoice.
         * </details>
         * 
         * <returns>
         * No Return (void)
         * </returns>
         */
        private void completeOrder_Click(object sender, RoutedEventArgs e)
        {

        }




        /**
         * <summary>
         * Displays all active Orders
         * </summary>
         * 
         * <param name="e">The state of the click object</param>
         * <param name="sender">The object that is being passed</param>
         * 
         * <details>
         * Opens a dialog window and displays a list and status of all the active Orders.
         * </details>
         * 
         * <returns>
         * No Return (void)
         * </returns>
         */
        private void activeOrders_Click(object sender, RoutedEventArgs e)
        {

        }



        /**
         * <summary>
         * Generates a summary report of all the Invoices for completed Orders (Simulated All Time)
         * </summary>
         * 
         * <param name="e">The state of the click object</param>
         * <param name="sender">The object that is being passed</param>
         * 
         * <details>
         * Generates a summary report of all the Invoices for completed Orders.
         * Note: It is not stated in requirements if this is just to display or save to text file
         * Currently the summary will open a dialog window and display the report.
         * </details>
         * 
         * <returns>
         * No Return (void)
         * </returns>
         */
        private void allTime_Click(object sender, RoutedEventArgs e)
        {

        }




        /**
         * <summary>
         * Generates a summary report of the Invoices for completed Orders from the past 2-Weeks (Simulated)
         * </summary>
         * 
         * <param name="e">The state of the click object</param>
         * <param name="sender">The object that is being passed</param>
         * 
         * <details>
         * Generates a summary report of the Invoices for completed Orders from the past 2-Weeks (Simulated)
         * Note: It is not stated in requirements if this is just to display or save to text file
         * Currently the summary will open a dialog window and display the report.
         * </details>
         * 
         * <returns>
         * No Return (void)
         * </returns>
         */
        private void pastTwoWeeks_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
